sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("zcapexapprover.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map